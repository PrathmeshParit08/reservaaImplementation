package com.reservaaa.reserva1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Reserva1Application {

	public static void main(String[] args) {
		SpringApplication.run(Reserva1Application.class, args);
	}

}
