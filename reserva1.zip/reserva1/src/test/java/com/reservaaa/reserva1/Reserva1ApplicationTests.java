package com.reservaaa.reserva1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reserva1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
